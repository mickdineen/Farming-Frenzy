﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;



public class SettingsMenu : MonoBehaviour {
	public GameObject SettingsMenuHolder;
	public Toggle[] resolutionToggles;
	public int[] ScreenWidths; 
	int activeScreenResIndex;



	public void SetScreenResolution(int i){

		if(resolutionToggles[i].isActiveAndEnabled){
			activeScreenResIndex= i;
			float aspectRatio = 16 / 9f;
			Screen.SetResolution (ScreenWidths[i], (int)(ScreenWidths [i] / aspectRatio), false);
		}
	}

	public void SetFullScreen(bool isFullscreen){

		for (int i = 0; i < resolutionToggles.Length; i++) {
			resolutionToggles [i].interactable = !isFullscreen;

					}
		if (isFullscreen) {
			Resolution[] allResolutions = Screen.resolutions;
			Resolution maxResolution = allResolutions[allResolutions.Length - 1];
			Screen.SetResolution (maxResolution.width, maxResolution.height, true);
					}
					else{ SetScreenResolution(activeScreenResIndex);
						
		}
	}
}