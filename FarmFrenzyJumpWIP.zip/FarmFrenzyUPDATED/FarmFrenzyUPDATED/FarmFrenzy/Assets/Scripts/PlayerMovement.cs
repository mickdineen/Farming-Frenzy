﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour {

	private Rigidbody2D myRigidbody;

	[SerializeField]
	private float movementSpeed;

	[SerializeField]
	private Transform[] groundPoints;

	[SerializeField]
	private float groundRadius;

	[SerializeField]
	private LayerMask whatIsGround;

	private bool isGrounded;

	private bool jump;

	[SerializeField]
	private float jumpForce;

	// Use this for initialization
	void Start () {
		myRigidbody = GetComponent<Rigidbody2D> ();
	}
	
	// Update is called once per frame
	void FixedUpdate () {

		float horizontal = Input.GetAxis ("Horizontal");

		isGrounded = IsGrounded();

		Movements(horizontal);

	}

	private void Movements(float horizontal){

		myRigidbody.velocity = new Vector2 (horizontal * movementSpeed, myRigidbody.velocity.y);

		if (isGrounded && jump) {
			isGrounded = false;
			myRigidbody.AddForce(new Vector2(0,jumpForce));
		}
			
	}

	private void Inputs(){
		if (Input.GetKeyDown(KeyCode.Space)){
			jump = true;
		}
	}

	public void ResetValues(){
		jump = false;
	}


	private bool IsGrounded(){
		if (myRigidbody.velocity.y <= 0) {
			foreach (Transform point in groundPoints) {
				Collider2D[] colliders = Physics2D.OverlapCircleAll (point.position, groundRadius, whatIsGround);

				for (int i = 0; i < colliders.Length; i++) {
					if (colliders [i].gameObject != gameObject) {
						return true;
					}
				}
			}

		}
		return false;
	
	}

}
