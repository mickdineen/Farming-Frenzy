﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour {

    //Movement variables
    public float speed;
    public float jump;
    float moveVelocity;
    bool grounded = false;
    bool attack = false;
    private Animator anim;

	// Use this for initialization
	void Start () {
        anim = GetComponent<Animator>();
	}
	
	// Update is called once per frame
	void Update () {
        // Jump
        
        if (Input.GetKeyDown(KeyCode.UpArrow) || Input.GetKeyDown(KeyCode.W))
        {
            if (grounded)
            {
                GetComponent<Rigidbody2D>().velocity = new Vector2(GetComponent<Rigidbody2D>().velocity.x, jump);
            }
        }//end if
        moveVelocity = 0;

        // Horizontal Movement code
        if(Input.GetKey (KeyCode.LeftArrow)|| Input.GetKey(KeyCode.A))
        {
            moveVelocity = -speed; //this causes the user to move left by inverting the speed of the character
            anim.SetTrigger("walk1");
        }

        // Horizontal Movement code
        if (Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.D))
        {
            moveVelocity = speed; //this causes the user to move left by inverting the speed of the character
            anim.SetTrigger("walk1");
        }
        GetComponent<Rigidbody2D>().velocity = new Vector2(moveVelocity, GetComponent<Rigidbody2D>().velocity.y);

        HandleInput();
        HandleAttack();
        HandleReset();
    }

    void OnTriggerEnter2D()
    {
        grounded = true; 
    }
    private void OnTriggerExit2D()
    {
        grounded = false;
    }
    
    private void HandleAttack()
    {
        if (attack)
        {
            anim.SetTrigger("attack1");
        }
    }

    private void HandleInput()
    {
        if (Input.GetKeyDown(KeyCode.P))
        {
            attack = true;
        }
    }

    private void HandleReset()
    {
        if (Input.GetKeyDown(KeyCode.P))
        {
            attack = false;
        }
    }
}

